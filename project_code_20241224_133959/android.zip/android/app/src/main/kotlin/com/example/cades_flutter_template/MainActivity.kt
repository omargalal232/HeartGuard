package com.example.heartguard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
